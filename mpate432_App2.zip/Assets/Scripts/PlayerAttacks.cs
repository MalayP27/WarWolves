using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAttacks : MonoBehaviour
{

    [SerializeField] private float attackCD;
    [SerializeField] private Transform firePoint;
    [SerializeField] private GameObject[] tornados;
    private Animator anim;
    private PlayerMovement playerMovement;
    private float cDTimer = Mathf.Infinity;
    // Start is called before the first frame update
    private void Awake()
    {
        anim = GetComponent<Animator>();
        playerMovement =  GetComponent<PlayerMovement>();
    }

    // Update is called once per frame
    private void Update()
    {
        if(Input.GetKey(KeyCode.I) && cDTimer > attackCD && playerMovement.canAttack())
        {
            Attack();
        }

        cDTimer += Time.deltaTime;
    }

    private void Attack()
    {
        anim.SetTrigger("SwordSwing");
        cDTimer = 0;

        tornados[FindTornados()].transform.position = firePoint.position;
        tornados[FindTornados()].GetComponent<Projectile>().SetDirection(Mathf.Sign(transform.localScale.x));    
    }

    private int FindTornados()
    {
        for(int i = 0; i < tornados.Length; i++)
        {
            if(!tornados[i].activeInHierarchy)
            {
                return i;
            }
        }
        return 0;
    }
}
